#!/bin/sh
export PYTHONPATH=modules
python app.py 